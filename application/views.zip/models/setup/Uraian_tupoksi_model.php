<?php
if (! defined ( 'BASEPATH' )) exit ( 'No direct script access allowed' );
class uraian_tupoksi_model extends CI_Model {
	function __construct() {
		parent::__construct ();
	}
	
	public function record_count() {
		return $this->db->count_all("uraian_tupoksi_tbl");
	}
	
	public function fetchAll($id,$limit, $start) {
		$this->db->select ('ut.id_tupoksi, t.tupoksi, ut.id_uraian, ut.uraian_tupoksi, ut.aktif');
		$this->db->from ('uraian_tupoksi_tbl ut');
		$this->db->join ('tupoksi_tbl t','t.id_tupoksi = ut.id_tupoksi');
		$this->db->where('ut.id_tupoksi',$id);
		$this->db->limit ($limit, $start);
		$query = $this->db->get ();
		if ($query->num_rows()> 0) {
			foreach ( $query->result () as $row ) {
				$data [] = $row;
			}
			return $data;
		}
		return false;
	}
	
	public function fetchById($id,$id2){
		$this->db->select ('ut.id_tupoksi, t.tupoksi, ut.id_uraian, ut.uraian_tupoksi, ut.aktif');
		$this->db->from ('uraian_tupoksi_tbl ut');
		$this->db->join ('tupoksi_tbl t','t.id_tupoksi = ut.id_tupoksi');
		$this->db->where('ut.id_tupoksi',$id);		
		$this->db->where('ut.id_uraian',$id);
		$query = $this->db->get()->result_array();
		return $query;
	}
	
	public function create($data) {
		$this->id_tupoksi = $data['id_tupoksi'];
		$this->id_uraian = $data['id_uraian'];
		$this->uraian_tupoksi = $data['uraian_tupoksi'];
		$this->aktif = $data['aktif'];
		
		// insert data
		$this->db->insert('uraian_tupoksi_tbl', $this);
	}

	public function update($data) {
		// get data
		$this->uraian_tupoksi = $data['uraian_tupoksi'];
		$this->aktif = $data['aktif'];
		
		// update data
		$this->db->update ('uraian_tupoksi_tbl', $this, array ('id_tupoksi' => $data['id_tupoksi'],'id_uraian'=> $data['id_uraian']));
	}
	
	public function delete($id,$id2) {
		$this->db->delete ('uraian_tupoksi_tbl', array ('id_tupoksi' => $id,'id_uraian'=> $id2));
	}
	
	public function search_count($column, $data){
		$this->db->where($column,$data);
		return  $this->db->count_all('uraian_tupoksi_tbl');
	}
	
	public function getName($id,$id2){
		$this->db->select('uraian_tupoksi');
		$this->db->from('uraian_tupoksi_tbl');
		$this->db->where('id_tupoksi',$id);
		$this->db->where('id_uraian',$id2);
		$query= $this->db->get();
		$ret = $query->row();
		return $ret->uraian_tupoksi;
	}
	
	public function search($column,$value, $limit, $start){
		
		$this->db->select ('*');
		$this->db->from ('uraian_tupoksi_tbl');
		$this->db->like($column,$value);
		$this->db->limit ($limit, $start);
		$query = $this->db->get();
		if ($query->num_rows()> 0) {
			foreach ( $query->result() as $row ) {
				$data [] = $row;
			}
			return $data;
		}
		return false;
	}
	
}