<?php
if (! defined ( 'BASEPATH' )) exit ( 'No direct script access allowed' );
class Tupoksi_model extends CI_Model {
	function __construct() {
		parent::__construct ();
	}
	
	public function record_count() {
		return $this->db->count_all("tupoksi_tbl");
	}
	
	public function fetchAll($limit, $start) {
		$this->db->select ('*');
		$this->db->from ('tupoksi_tbl');
		$this->db->limit ($limit, $start);
		$query = $this->db->get ();
		if ($query->num_rows()> 0) {
			foreach ( $query->result () as $row ) {
				$data [] = $row;
			}
			return $data;
		}
		return false;
	}
	
	public function fetchById($id){
		$this->db->select ('*');
		$this->db->from ('tupoksi_tbl');
		$query = $this->db->get()->result_array();
		return $query;
	}
	
	public function create($data) {
		$this->id_tupoksi = $data['id_tupoksi'];
		$this->tupoksi = $data['tupoksi'];
		$this->dasar_hukum = $data['dasar_hukum'];
		$this->tahun = $data['tahun'];
		$this->aktif = $data['aktif'];
		
		// insert data
		$this->db->insert('tupoksi_tbl', $this);
	}

	public function update($data) {
		// get data
		$this->tupoksi = $data['tupoksi'];
		$this->dasar_hukum = $data['dasar_hukum'];
		$this->tahun = $data['tahun'];
		$this->aktif = $data['aktif'];
		
		// update data
		$this->db->update ('tupoksi_tbl', $this, array ('id_tupoksi' => $data['id_tupoksi']));
	}
	
	public function delete($id) {
		$this->db->delete ('tupoksi_tbl', array ('id_tupoksi' => $id));
	}
	
	public function search_count($column, $data){
		$this->db->where($column,$data);
		return  $this->db->count_all('tupoksi_tbl');
	}
	
	public function getName($id){
		$this->db->select('tupoksi');
		$this->db->from('tupoksi_tbl');
		$this->db->where('id_tupoksi',$id);
		$query= $this->db->get();
		$ret = $query->row();
		return $ret->tupoksi;
	}
	
	public function search($column,$value, $limit, $start){
		
		$this->db->select ('*');
		$this->db->from ('tupoksi_tbl');
		$this->db->like($column,$value);
		$this->db->limit ($limit, $start);
		$query = $this->db->get();
		if ($query->num_rows()> 0) {
			foreach ( $query->result() as $row ) {
				$data [] = $row;
			}
			return $data;
		}
		return false;
	}
	
}