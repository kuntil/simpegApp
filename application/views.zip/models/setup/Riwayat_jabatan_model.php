<?php
if (! defined ( 'BASEPATH' )) exit ( 'No direct script access allowed' );
class riwayat_jabatan_model extends CI_Model {
	function __construct() {
		parent::__construct ();
	}
	
	public function record_count($nip) {
		$this->db->where('nip',$nip);
		return $this->db->count_all("riwayat_jabatan_tbl");
	}
	
	public function fetchAll($limit, $start,$nip) {
		$this->db->select ('rj.nip, p.nama, rj.seq_no, rj.valid_from, rj.valid_to, rj.unit_kerja, rj.jenis_jabatan, rj.esselon, rj.esselon, rj.esselon, rj.no_sk, rj.tgl_sk, rj.valid_jabatan');
		$this->db->from ('riwayat_jabatan_tbl rj');
		$this->db->join ('pegawai_tbl p','rj.nip = p.nip');
		$this->db->where('rj.nip',$nip);
		$this->db->limit ($limit, $start);
		$query = $this->db->get ();
		if ($query->num_rows()> 0) {
			foreach ( $query->result () as $row ) {
				$data [] = $row;
			}
			return $data;
		}
		return false;
	}
	
	public function fetchById($nip,$seq_no){
		$this->db->select ('rj.nip, p.nama, rj.seq_no, rj.valid_from, rj.valid_to, rj.unit_kerja, rj.jenis_jabatan, rj.esselon, rj.esselon, rj.esselon, rj.no_sk, rj.tgl_sk, rj.valid_jabatan');
		$this->db->from ('riwayat_jabatan_tbl rj');
		$this->db->join ('pegawai_tbl p','rj.nip = p.nip');
		$this->db->where('rj.nip',$nip);
		$this->db->where('rj.seq_no',$seq_no);
		$query = $this->db->get()->result_array();
		return $query;
	}
	
	public function create($data) {
		$this->nip = $data['nip'];
		$this->seq_no = $data['seq_no'];
		$this->valid_from = $data['valid_from'];
		$this->valid_to = $data['valid_to'];
		$this->unit_kerja = $data['unit_kerja'];
		$this->jenis_jabatan = $data['jenis_jabatan'];
		$this->nama_jabatan = $data['nama_jabatan'];
		$this->esselon = $data['esselon'];
		$this->no_sk = $data['no_sk'];
		$this->tgl_sk = $data['tgl_sk'];
		$this->valid_jabatan = $data['valid_jabatan'];
		
		// insert data
		$this->db->insert('riwayat_jabatan_tbl', $this);
	}

	public function update($data) {
		// get data
		$this->valid_from = $data['valid_from'];
		$this->valid_to = $data['valid_to'];
		$this->unit_kerja = $data['unit_kerja'];
		$this->jenis_jabatan = $data['jenis_jabatan'];
		$this->nama_jabatan = $data['nama_jabatan'];
		$this->esselon = $data['esselon'];
		$this->no_sk = $data['no_sk'];
		$this->tgl_sk = $data['tgl_sk'];
		$this->valid_jabatan = $data['valid_jabatan'];
		
		// update data
		$this->db->update ('riwayat_jabatan_tbl', $this, array ('nip' => $data['nip'],'seq_no' => $data['seq_no']));
	}
	
	public function delete($id, $seq_no) {
		$this->db->delete ('riwayat_jabatan_tbl', array ('nip' => $id,'seq_no'=> $seq_no));
	}
	
	public function search_count($column, $data,$nip){
		$this->db->where('nip',$nip);
		$this->db->where($column,$data);
		return  $this->db->count_all('riwayat_jabatan_tbl');
	}
	
	public function generateSeqNo($nip){
		return $this->db->query("SELECT ifnull(max(seq_no),0) seq_no FROM riwayat_jabatan_tbl WHERE nip='".$nip."'")->row()->seq_no+1;
	}
	
	public function search($column,$value, $nip, $limit, $start){
		
		$this->db->select ('rj.nip, p.nama, rj.seq_no, rj.valid_from, rj.valid_to, rj.unit_kerja, rj.jenis_jabatan, rj.esselon, rj.esselon, rj.esselon, rj.no_sk, rj.tgl_sk, rj.valid_jabatan');
		$this->db->from ('riwayat_jabatan_tbl rj');
		$this->db->join ('pegawai_tbl p','rj.nip = p.nip');
		$this->db->where('rj.nip',$nip);
		$this->db->like($column,$value);
		$this->db->limit ($limit, $start);
		$query = $this->db->get('riwayat_jabatan_tbl rh');
		if ($query->num_rows()> 0) {
			foreach ( $query->result() as $row ) {
				$data [] = $row;
			}
			return $data;
		}
		return false;
		
	}
	
}